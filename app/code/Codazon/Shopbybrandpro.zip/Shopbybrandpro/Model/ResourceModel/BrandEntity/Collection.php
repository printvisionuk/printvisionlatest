<?php
namespace Codazon\Shopbybrandpro\Model\ResourceModel\BrandEntity;

class Collection extends AbstractCollection
{
	protected function _construct()
    {
		$this->_init('Codazon\Shopbybrandpro\Model\Brand', 'Codazon\Shopbybrandpro\Model\ResourceModel\BrandEntity');
    }
}

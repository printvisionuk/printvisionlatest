<?php
namespace Codazon\Shopbybrandpro\Block\Widget;

class BrandList extends \Codazon\Shopbybrandpro\Block\Widget\BrandAbstract
{
	protected $_template = 'brand/brand_list.phtml';
	protected $_cacheTag = 'BRAND_SEARCH';
}